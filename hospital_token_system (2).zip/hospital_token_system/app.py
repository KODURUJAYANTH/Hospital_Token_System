from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///hospital.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    specialty = db.Column(db.String(100), nullable=False)
    available = db.Column(db.Boolean, default=True)

class Token(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_name = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    token_number = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_served = db.Column(db.Boolean, default=False)

@app.before_first_request
def create_tables():
    db.create_all()
    if not Doctor.query.first():
        doctors = [
            Doctor(name='Dr. Ravi Kumar', specialty='Cardiology'),
            Doctor(name='Dr. Sita Mehta', specialty='Neurology'),
            Doctor(name='Dr. John Dsouza', specialty='Orthopedics')
        ]
        db.session.bulk_save_objects(doctors)
        db.session.commit()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/doctors')
def doctors():
    doctor_list = Doctor.query.all()
    return render_template('doctors.html', doctors=doctor_list)

@app.route('/get-token', methods=['GET', 'POST'])
def get_token():
    if request.method == 'POST':
        name = request.form['patient_name']
        dept = request.form['department']
        last_token = Token.query.filter_by(department=dept).order_by(Token.token_number.desc()).first()
        next_token = 1 if not last_token else last_token.token_number + 1
        new_token = Token(patient_name=name, department=dept, token_number=next_token)
        db.session.add(new_token)
        db.session.commit()
        flash(f'Token generated: {next_token} for {dept}')
        return redirect(url_for('token_display'))
    return render_template('get_token.html')

@app.route('/token-display')
def token_display():
    tokens = Token.query.order_by(Token.created_at).all()
    now_serving = Token.query.filter_by(is_served=False).order_by(Token.token_number).first()
    return render_template('token_display.html', tokens=tokens, now_serving=now_serving)

@app.route('/serve-next')
def serve_next():
    next_token = Token.query.filter_by(is_served=False).order_by(Token.token_number).first()
    if next_token:
        next_token.is_served = True
        db.session.commit()
        flash(f"Now serving token #{next_token.token_number}")
    return redirect(url_for('token_display'))

@app.route('/reset-tokens')
def reset_tokens():
    # Only reset if all tokens are served
    if not Token.query.filter_by(is_served=False).first():
        Token.query.delete()
        db.session.commit()
        flash("✅ All tokens served. Queue has been reset.")
    else:
        flash("⚠️ There are still patients in the queue.")
    return redirect(url_for('token_display'))

if __name__ == '__main__':
    app.run(debug=True)
